package com.example.handy_hub

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
